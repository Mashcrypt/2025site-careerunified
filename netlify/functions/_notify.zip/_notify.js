var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/_notify.ts
var notify_exports = {};
__export(notify_exports, {
  sendApprovalEmail: () => sendApprovalEmail,
  sendTransactionalEmail: () => sendTransactionalEmail
});
module.exports = __toCommonJS(notify_exports);
var RESEND_ENDPOINT = "https://api.resend.com/emails";
var DEFAULT_FROM = "Career Unified <no-reply@mail.careerunified.com>";
function headerValue(value, maxLength = 254) {
  return String(value || "").replace(/[\r\n]+/g, " ").trim().slice(0, maxLength);
}
function validEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}
function recipientList(value) {
  const recipients = (Array.isArray(value) ? value : [value]).map((email) => headerValue(email).toLowerCase()).filter(validEmail);
  return [...new Set(recipients)].slice(0, 50);
}
function tagValue(value) {
  return headerValue(value, 128).toLowerCase().replace(/[^a-z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 128);
}
async function sendTransactionalEmail({
  to,
  subject,
  text,
  html,
  from,
  replyTo,
  tag
}) {
  const apiKey = headerValue(process.env.RESEND_API_KEY, 500);
  if (!apiKey) throw new Error("Resend is not configured.");
  const recipients = recipientList(to);
  if (!recipients.length) throw new Error("A valid email recipient is required.");
  const safeSubject = headerValue(subject, 180);
  if (!safeSubject) throw new Error("An email subject is required.");
  const payload = {
    from: headerValue(from || process.env.RESEND_FROM_EMAIL || DEFAULT_FROM),
    to: recipients,
    subject: safeSubject,
    text: String(text || "").slice(0, 12e3)
  };
  if (html) payload.html = String(html).slice(0, 5e4);
  const safeReplyTo = headerValue(replyTo);
  if (safeReplyTo && validEmail(safeReplyTo)) payload.reply_to = safeReplyTo;
  const safeTag = tagValue(tag);
  if (safeTag) payload.tags = [{ name: "category", value: safeTag }];
  const response = await fetch(RESEND_ENDPOINT, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    throw new Error(`Resend rejected the email with status ${response.status}.`);
  }
  const result = await response.json().catch(() => ({}));
  return { id: headerValue(result.id, 240) };
}
async function sendApprovalEmail(options) {
  return sendTransactionalEmail({ ...options, tag: "approval-notification" });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  sendApprovalEmail,
  sendTransactionalEmail
});
