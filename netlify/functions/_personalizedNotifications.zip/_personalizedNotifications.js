var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key2 of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key2) && key2 !== except)
        __defProp(to, key2, { get: () => from[key2], enumerable: !(desc = __getOwnPropDesc(from, key2)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/_personalizedNotifications.ts
var personalizedNotifications_exports = {};
__export(personalizedNotifications_exports, {
  matchesOpportunity: () => matchesOpportunity,
  processPersonalizedNotifications: () => processPersonalizedNotifications
});
module.exports = __toCommonJS(personalizedNotifications_exports);
var import_node_crypto = require("crypto");

// netlify/lib/sanity.ts
var PROJECT_ID = "qjg5raj1";
var DATASET = "production";
var API_VERSION = "2024-01-01";
function today() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
function slugify(value) {
  return String(value ?? "").toLowerCase().trim().replace(/&/g, "and").replace(/[-_]+/g, " ").replace(/\bapply\s+now\b/g, "").replace(/\bclosing\s+soon\b/g, "").replace(/\bor\s+apply\b/g, "").replace(/\bapply\b$/g, "").replace(/\bor\b/g, "").replace(/speciliast/g, "specialist").replace(/machanical/g, "mechanical").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}
async function querySanity(query, params = {}) {
  const search = new URLSearchParams({ query });
  Object.entries(params).forEach(([key2, value]) => search.set(`$${key2}`, JSON.stringify(value)));
  const url = `https://${PROJECT_ID}.api.sanity.io/v${API_VERSION}/data/query/${DATASET}?${search}`;
  const response = await fetch(url, { headers: { Accept: "application/json" } });
  if (!response.ok) {
    throw new Error(`Sanity fetch failed: ${response.status}`);
  }
  const json = await response.json();
  return json.result;
}
function cleanJobSlug(value) {
  return slugify(String(value ?? "").replace(/--[a-z0-9]+$/i, ""));
}
function cleanJobTitle(value) {
  return String(value ?? "").replace(/speciliast/gi, "specialist").replace(/machanical/gi, "mechanical").trim();
}
function normalizeJob(job) {
  if (!job) return job;
  return {
    ...job,
    title: cleanJobTitle(job.title),
    slug: cleanJobSlug(job.slug || job.title || job._id)
  };
}
async function getActiveJobs(limit = 200) {
  const jobs = await querySanity(
    `*[_type == "job" && (!defined(deadline) || deadline >= $today)]
      | order(posted desc)[0...${limit}]{
        _id, _createdAt, _updatedAt, title, "slug": coalesce(slug.current, _id), location, salary,
        posted, deadline, deadlineText, jobType, category, description, "companyName": company->name,
        "companyLogo": company->logo.asset->url
      }`,
    { today: today() }
  );
  return Array.isArray(jobs) ? jobs.map((job) => normalizeJob(job)).filter(Boolean) : [];
}
async function getActiveBursaries(limit = 200) {
  return querySanity(
    `*[_type == "bursary" && (!defined(deadline) || deadline >= $today)]
      | order(deadline asc)[0...${limit}]{
        _id, _createdAt, _updatedAt, name, "slug": coalesce(slug.current, _id), provider, faculty, faculties,
        deadline, description
      }`,
    { today: today() }
  );
}
async function getUniversities(limit = 200) {
  const universities = await querySanity(
    `*[_type == "university"] | order(deadline asc, name asc)[0...${limit}]{
      _id, _updatedAt, name, "slug": slug.current, applicationLink, applicationFee,
      registrationFee, deadline, notes, city, province
    }`
  );
  return (universities || []).map((university) => ({
    ...university,
    slug: university.slug || slugify(university.name)
  }));
}
async function getCareerGuides(limit = 50) {
  return querySanity(
    `*[_type == "cvTip"] | order(_updatedAt desc)[0...${limit}]{
      _id, _createdAt, _updatedAt, title, category
    }`
  );
}

// netlify/functions/_notify.ts
var RESEND_ENDPOINT = "https://api.resend.com/emails";
var DEFAULT_FROM = "Career Unified <no-reply@mail.careerunified.com>";
function headerValue(value, maxLength = 254) {
  return String(value || "").replace(/[\r\n]+/g, " ").trim().slice(0, maxLength);
}
function validEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}
function recipientList(value) {
  const recipients = (Array.isArray(value) ? value : [value]).map((email) => headerValue(email).toLowerCase()).filter(validEmail);
  return [...new Set(recipients)].slice(0, 50);
}
function tagValue(value) {
  return headerValue(value, 128).toLowerCase().replace(/[^a-z0-9_-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 128);
}
async function sendTransactionalEmail({
  to,
  subject,
  text,
  html,
  from,
  replyTo,
  tag
}) {
  const apiKey = headerValue(process.env.RESEND_API_KEY, 500);
  if (!apiKey) throw new Error("Resend is not configured.");
  const recipients = recipientList(to);
  if (!recipients.length) throw new Error("A valid email recipient is required.");
  const safeSubject = headerValue(subject, 180);
  if (!safeSubject) throw new Error("An email subject is required.");
  const payload = {
    from: headerValue(from || process.env.RESEND_FROM_EMAIL || DEFAULT_FROM),
    to: recipients,
    subject: safeSubject,
    text: String(text || "").slice(0, 12e3)
  };
  if (html) payload.html = String(html).slice(0, 5e4);
  const safeReplyTo = headerValue(replyTo);
  if (safeReplyTo && validEmail(safeReplyTo)) payload.reply_to = safeReplyTo;
  const safeTag = tagValue(tag);
  if (safeTag) payload.tags = [{ name: "category", value: safeTag }];
  const response = await fetch(RESEND_ENDPOINT, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });
  if (!response.ok) {
    throw new Error(`Resend rejected the email with status ${response.status}.`);
  }
  const result = await response.json().catch(() => ({}));
  return { id: headerValue(result.id, 240) };
}

// netlify/functions/_personalizedNotifications.ts
var INDUSTRIES = {
  "Accounting & Finance": ["accounting", "finance", "audit", "banking", "actuarial", "tax"],
  "Information Technology": ["software", "developer", "technology", "information technology", "data", "cyber"],
  Engineering: ["engineer", "engineering", "mechanical", "electrical", "civil"],
  Healthcare: ["health", "medical", "nursing", "pharmacy"],
  Education: ["education", "teacher", "teaching", "university", "school"],
  Legal: ["legal", "law", "attorney"],
  Marketing: ["marketing", "communications", "brand", "media"],
  "Human Resources": ["human resources", "recruitment", "talent", "hr "],
  Administration: ["administration", "administrator", "clerk", "office"],
  Retail: ["retail", "store", "sales assistant"],
  Government: ["government", "department", "municipal", "public service", "saps", "defence force"]
};
function list(value) {
  return Array.isArray(value) ? value.filter((item) => typeof item === "string") : [];
}
function preferences(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const data = value;
  if (data.enabled !== true) return null;
  const frequency = ["instant", "daily", "weekly"].includes(String(data.frequency)) ? String(data.frequency) : "daily";
  return {
    enabled: true,
    opportunityTypes: list(data.opportunityTypes),
    industries: list(data.industries),
    channels: list(data.channels),
    frequency,
    updates: list(data.updates)
  };
}
function date(value) {
  if (value && typeof value.toDate === "function") {
    return value.toDate();
  }
  const parsed = new Date(String(value || ""));
  return Number.isNaN(parsed.getTime()) ? /* @__PURE__ */ new Date(0) : parsed;
}
function inferIndustries(...values) {
  const text = values.map((value) => String(value || "")).join(" ").toLowerCase();
  return Object.entries(INDUSTRIES).filter(([, keywords]) => keywords.some((keyword) => text.includes(keyword))).map(([industry]) => industry);
}
function jobTypes(category, title) {
  const types = /* @__PURE__ */ new Set(["Jobs"]);
  const value = String(category || "").toLowerCase();
  const mapped = {
    internship: "Internships",
    learnership: "Learnerships",
    "graduate-program": "Graduate Programmes",
    "yes-programmes": "YES Programmes",
    "youth-opportunities": "Youth Opportunities",
    "vacation-work": "Vacation Work",
    "part-time": "Part-time Jobs"
  };
  if (mapped[value]) types.add(mapped[value]);
  const text = String(title || "").toLowerCase();
  if (/matric|grade 12/.test(text)) types.add("Matric Opportunities");
  if (/entry.level|no experience/.test(text)) types.add("Entry-level / No Experience");
  if (/government|department|municipal|public service|saps|defence force/.test(text)) types.add("Government Vacancies");
  return [...types];
}
function matches(item, prefs) {
  if (!item.types.some((type) => prefs.opportunityTypes.includes(type))) return false;
  if (!item.industries.length) return true;
  if (!prefs.industries.length || prefs.industries.includes("General / Any Industry")) return true;
  return item.industries.some((industry) => prefs.industries.includes(industry));
}
function escapeHtml(value) {
  return String(value || "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[character] || character);
}
function digestEmail(items, reminders, frequency) {
  const rows = [...reminders, ...items].slice(0, 12);
  const heading = frequency === "weekly" ? "Your weekly Career Unified update" : "New opportunities selected for you";
  const htmlRows = rows.map((item) => `<tr><td style="padding:14px 0;border-bottom:1px solid #e5e7eb"><a href="${escapeHtml(item.url)}" style="color:#185FA5;font-weight:600;text-decoration:none">${escapeHtml(item.title)}</a><div style="color:#64748b;font-size:13px;margin-top:4px">${escapeHtml(item.kind)}${item.deadline ? ` \xB7 Closing ${escapeHtml(item.deadline)}` : ""}</div></td></tr>`).join("");
  const text = [heading, "", ...rows.map((item) => `${item.title}${item.deadline ? ` (closes ${item.deadline})` : ""}
${item.url}`), "", "Manage alerts: https://careerunified.com/account-page.html?tab=notifications"].join("\n");
  return {
    subject: reminders.length ? `${reminders.length} closing reminder${reminders.length === 1 ? "" : "s"} and new matches` : heading,
    text,
    html: `<div style="font-family:Arial,sans-serif;max-width:620px;margin:auto;color:#0f172a"><h1 style="font-size:22px">${escapeHtml(heading)}</h1><p style="color:#475569">These updates match the choices in your Career Unified notification settings.</p><table style="width:100%;border-collapse:collapse">${htmlRows}</table><p style="font-size:12px;color:#64748b;margin-top:24px">You are receiving this because personalised email alerts are enabled. <a href="https://careerunified.com/account-page.html?tab=notifications" style="color:#185FA5">Manage alerts</a>.</p></div>`
  };
}
function key(...parts) {
  return (0, import_node_crypto.createHash)("sha256").update(parts.join("|")).digest("hex").slice(0, 40);
}
function bucket(now, frequency) {
  const iso = now.toISOString().slice(0, 10);
  if (frequency !== "weekly") return iso;
  const first = new Date(Date.UTC(now.getUTCFullYear(), 0, 1));
  return `${now.getUTCFullYear()}-${Math.ceil(((now.getTime() - first.getTime()) / 864e5 + first.getUTCDay() + 1) / 7)}`;
}
async function claim(db, uid, id, data) {
  const ref = db.doc(`users/${uid}/notificationDeliveries/${id}`);
  return db.runTransaction(async (transaction) => {
    const snapshot = await transaction.get(ref);
    if (snapshot.exists) {
      const existing = snapshot.data() || {};
      const failedAt = date(existing.failedAt);
      if (existing.status !== "failed" || Date.now() - failedAt.getTime() < 60 * 6e4) return false;
      transaction.set(ref, { ...data, status: "claimed", retriedAt: /* @__PURE__ */ new Date() }, { merge: true });
      return true;
    }
    transaction.create(ref, { ...data, status: "claimed", createdAt: /* @__PURE__ */ new Date() });
    return true;
  });
}
async function recentOpportunities(admin, since) {
  const db = admin.firestore();
  const [sanityJobs, bursaries, universities, recruiterJobs] = await Promise.all([
    getActiveJobs(250),
    getActiveBursaries(150),
    getUniversities(100),
    db.collection("jobs").where("status", "==", "active").limit(250).get()
  ]);
  const result = [];
  for (const raw of sanityJobs) {
    const publishedAt = date(raw._createdAt || raw.posted);
    if (publishedAt < since) continue;
    result.push({ id: `sanity-job-${raw._id}`, title: raw.title, kind: "Job", types: jobTypes(raw.category, raw.title), industries: inferIndustries(raw.category, raw.title, raw.description), url: `https://careerunified.com/jobs/${raw.slug}`, deadline: raw.deadline || raw.deadlineText, publishedAt });
  }
  for (const raw of recruiterJobs.docs.map((doc) => ({ id: doc.id, ...doc.data() }))) {
    const publishedAt = date(raw.createdAt || raw.updatedAt);
    if (publishedAt < since) continue;
    const slug = raw.slug || raw.id;
    result.push({ id: `recruiter-job-${raw.id}`, title: raw.title, kind: "Job", types: jobTypes(raw.category || raw.type, raw.title), industries: raw.companyIndustry ? [raw.companyIndustry] : inferIndustries(raw.title, raw.description), url: `https://careerunified.com/jobs/${slug}`, deadline: raw.deadline, publishedAt });
  }
  for (const raw of bursaries) {
    const publishedAt = date(raw._createdAt || raw._updatedAt);
    if (publishedAt < since) continue;
    result.push({ id: `bursary-${raw._id}`, title: raw.name, kind: "Bursary", types: ["Bursaries"], industries: inferIndustries(raw.faculty, raw.faculties, raw.description), url: `https://careerunified.com/bursary/${raw.slug}`, deadline: raw.deadline, publishedAt });
  }
  for (const raw of universities) {
    const publishedAt = date(raw._createdAt || raw._updatedAt);
    if (publishedAt < since) continue;
    result.push({ id: `university-${raw._id}`, title: raw.name, kind: "University application", types: ["University Applications"], industries: [], url: `https://careerunified.com/varsity/${raw.slug}`, deadline: raw.deadline, publishedAt });
  }
  return result;
}
async function recentCareerUpdates(admin, since) {
  const db = admin.firestore();
  const [guides, updates] = await Promise.all([
    getCareerGuides(50),
    db.collection("careerUpdates").where("published", "==", true).limit(50).get().catch(() => null)
  ]);
  const result = [];
  for (const raw of guides || []) {
    const publishedAt = date(raw._updatedAt || raw._createdAt);
    if (publishedAt < since) continue;
    result.push({ id: `guide-${raw._id}`, title: raw.title, kind: raw.category || "Career guide", types: [], industries: [], url: "https://careerunified.com/cv-tips", publishedAt });
  }
  for (const document of updates?.docs || []) {
    const raw = document.data();
    const publishedAt = date(raw.publishedAt || raw.createdAt);
    if (publishedAt < since) continue;
    const url = String(raw.url || "");
    result.push({ id: `career-update-${document.id}`, title: String(raw.title || "Career Unified update"), kind: raw.kind === "event" ? "Career event" : "Career guide", types: [], industries: [], url: url.startsWith("https://careerunified.com/") ? url : "https://careerunified.com/cv-tips", publishedAt });
  }
  return result;
}
async function deadlineReminders(db, uid) {
  const saved = await db.collection(`users/${uid}/saved`).limit(100).get();
  const today2 = /* @__PURE__ */ new Date();
  today2.setHours(0, 0, 0, 0);
  return saved.docs.flatMap((document) => {
    const raw = document.data();
    const deadline = date(raw.deadlineDate || raw.deadline);
    deadline.setHours(0, 0, 0, 0);
    const days = Math.round((deadline.getTime() - today2.getTime()) / 864e5);
    if (![1, 3, 7].includes(days)) return [];
    const isBursary = raw.type === "bursary";
    return [{ id: `deadline-${document.id}-${deadline.toISOString().slice(0, 10)}`, title: raw.title || raw.name || "Saved opportunity", kind: `${days} day closing reminder`, types: [isBursary ? "Bursaries" : "Jobs"], industries: [], url: isBursary ? `https://careerunified.com/bursary/${raw.slug || ""}` : `https://careerunified.com/jobs/${raw.slug || ""}`, deadline: deadline.toISOString().slice(0, 10), publishedAt: /* @__PURE__ */ new Date() }];
  });
}
async function processPersonalizedNotifications(admin, options = {}) {
  const db = admin.firestore();
  const now = /* @__PURE__ */ new Date();
  const stateRef = db.doc("system/personalizedNotificationProcessor");
  const state = await stateRef.get();
  const cursor = state.data()?.cursor;
  const testEmails = (options.testEmails || []).map((email) => email.toLowerCase()).slice(0, 30);
  let query = testEmails.length ? db.collection("users").where("email", "in", testEmails).limit(options.limit || 75) : db.collection("users").where("notificationPreferences.enabled", "==", true).orderBy("__name__").limit(options.limit || 75);
  if (cursor && !testEmails.length) query = query.startAfter(cursor);
  let users = await query.get();
  if (users.empty && cursor && !testEmails.length) users = await db.collection("users").where("notificationPreferences.enabled", "==", true).orderBy("__name__").limit(options.limit || 75).get();
  const earliest = new Date(now.getTime() - 8 * 864e5);
  const [opportunities, careerUpdates] = await Promise.all([
    recentOpportunities(admin, earliest),
    recentCareerUpdates(admin, earliest)
  ]);
  let emails = 0;
  let inApp = 0;
  let eligibleUsers = 0;
  let matchedItems = 0;
  for (const user of users.docs) {
    const data = user.data();
    const prefs = preferences(data.notificationPreferences);
    if (!prefs) continue;
    const last = date(data.notificationDelivery?.[`last${prefs.frequency[0].toUpperCase()}${prefs.frequency.slice(1)}At`]);
    const wait = prefs.frequency === "instant" ? 10 * 6e4 : prefs.frequency === "daily" ? 20 * 36e5 : 6 * 864e5;
    if (last.getTime() && now.getTime() - last.getTime() < wait) continue;
    const since = last.getTime() ? last : new Date(now.getTime() - (prefs.frequency === "weekly" ? 8 : 2) * 864e5);
    const opportunityMatches = opportunities.filter((item) => item.publishedAt >= since && matchesOpportunity(item, prefs));
    const guideMatches = prefs.updates.includes("careerGuides") ? careerUpdates.filter((item) => item.publishedAt >= since) : [];
    const matches2 = [...opportunityMatches, ...guideMatches].sort((a, b) => b.publishedAt.getTime() - a.publishedAt.getTime()).slice(0, 20);
    const reminders = prefs.updates.includes("deadlineReminders") ? await deadlineReminders(db, user.id) : [];
    if (matches2.length || reminders.length) {
      eligibleUsers += 1;
      matchedItems += matches2.length + reminders.length;
    }
    if (options.dryRun) continue;
    const deliveryId = key("digest", user.id, prefs.frequency, bucket(now, prefs.frequency), [...reminders, ...matches2].map((item) => item.id).sort().join(","));
    if (!matches2.length && !reminders.length) {
      await user.ref.set({ notificationDelivery: { [`last${prefs.frequency[0].toUpperCase()}${prefs.frequency.slice(1)}At`]: now } }, { merge: true });
      continue;
    }
    if (!await claim(db, user.id, deliveryId, { frequency: prefs.frequency })) continue;
    if (prefs.channels.includes("inApp")) {
      const batch = db.batch();
      for (const item of [...reminders, ...matches2]) {
        batch.set(db.doc(`users/${user.id}/notifications/${key(item.id)}`), { title: item.title, message: item.deadline ? `${item.kind} \xB7 Closing ${item.deadline}` : item.kind, url: item.url, type: item.id.startsWith("deadline-") ? "deadline" : "match", read: false, createdAt: now }, { merge: true });
        inApp += 1;
      }
      await batch.commit();
    }
    const recipient = String(data.email || "").trim();
    try {
      if (prefs.channels.includes("email") && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(recipient)) {
        const message = digestEmail(matches2, reminders, prefs.frequency);
        await sendTransactionalEmail({ to: recipient, ...message, tag: "personalised-alert" });
        emails += 1;
      }
      await user.ref.set({ notificationDelivery: { [`last${prefs.frequency[0].toUpperCase()}${prefs.frequency.slice(1)}At`]: now } }, { merge: true });
      await db.doc(`users/${user.id}/notificationDeliveries/${deliveryId}`).set({ status: "sent", sentAt: now }, { merge: true });
    } catch (error) {
      await db.doc(`users/${user.id}/notificationDeliveries/${deliveryId}`).set({ status: "failed", failedAt: now }, { merge: true });
      console.error("PERSONALISED_NOTIFICATION_DELIVERY_FAILED", { userId: user.id, deliveryId });
    }
  }
  const lastUser = users.docs.at(-1);
  if (!options.dryRun && !testEmails.length) {
    await stateRef.set({ cursor: lastUser?.id || null, processedAt: now }, { merge: true });
  }
  return { dryRun: options.dryRun === true, restrictedToTestRecipients: testEmails.length > 0, users: users.size, eligibleUsers, matchedItems, emails, inApp };
}
var matchesOpportunity = matches;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  matchesOpportunity,
  processPersonalizedNotifications
});
