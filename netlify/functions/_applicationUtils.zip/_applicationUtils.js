var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/_applicationUtils.ts
var applicationUtils_exports = {};
__export(applicationUtils_exports, {
  ApplicationError: () => ApplicationError,
  bearerToken: () => bearerToken,
  cleanMultiline: () => cleanMultiline,
  cleanText: () => cleanText,
  corsHeaders: () => corsHeaders,
  hasAnswer: () => hasAnswer,
  json: () => json,
  normalizeAnswer: () => normalizeAnswer,
  parseJsonBody: () => parseJsonBody,
  safeFilename: () => safeFilename,
  storagePathFromCv: () => storagePathFromCv
});
module.exports = __toCommonJS(applicationUtils_exports);
var ApplicationError = class extends Error {
  statusCode;
  constructor(statusCode, message) {
    super(message);
    this.statusCode = statusCode;
  }
};
function corsHeaders(origin) {
  const allowed = process.env.ALLOWED_ORIGIN || "*";
  return {
    "Access-Control-Allow-Origin": allowed === "*" ? "*" : origin && origin === allowed ? origin : allowed,
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Max-Age": "86400"
  };
}
function json(statusCode, origin, body, extraHeaders) {
  return {
    statusCode,
    headers: {
      ...corsHeaders(origin),
      "Content-Type": "application/json",
      ...extraHeaders || {}
    },
    body: JSON.stringify(body)
  };
}
function parseJsonBody(event) {
  const raw = event.isBase64Encoded ? Buffer.from(event.body || "", "base64").toString("utf8") : event.body || "";
  try {
    return JSON.parse(raw || "{}");
  } catch {
    throw new ApplicationError(400, "Request body must be valid JSON.");
  }
}
function bearerToken(event) {
  const authHeader = event.headers.authorization || event.headers.Authorization;
  return authHeader?.startsWith("Bearer ") ? authHeader.slice(7).trim() : "";
}
function cleanText(value, maxLength = 240) {
  return String(value ?? "").replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, "").replace(/<[^>]+>/g, "").replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim().slice(0, maxLength);
}
function cleanMultiline(value, maxLength = 4e3) {
  return String(value ?? "").replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, "").replace(/<[^>]+>/g, "").replace(/\r\n?/g, "\n").replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, "").trim().slice(0, maxLength);
}
function safeFilename(value) {
  return cleanText(value, 160).replace(/[\\/:*?"<>|]+/g, "_").replace(/^\.+/, "") || "Candidate-CV.pdf";
}
function storagePathFromCv(cv) {
  const storedPath = cleanText(cv.cvFilePath, 600);
  if (storedPath.startsWith("cvs/")) return storedPath;
  const rawUrl = cleanText(cv.cvURL || cv.cvUrl, 1200);
  if (!rawUrl) return "";
  try {
    const parsed = new URL(rawUrl);
    if (parsed.hostname !== "firebasestorage.googleapis.com") return "";
    const encodedPath = parsed.pathname.split("/o/")[1];
    return encodedPath ? decodeURIComponent(encodedPath) : "";
  } catch {
    return "";
  }
}
function normalizeAnswer(value) {
  if (Array.isArray(value)) {
    return value.map((item) => cleanText(item, 200)).filter(Boolean).slice(0, 12);
  }
  return cleanMultiline(value, 1200);
}
function hasAnswer(value) {
  return Array.isArray(value) ? value.length > 0 : cleanText(value, 1200).length > 0;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ApplicationError,
  bearerToken,
  cleanMultiline,
  cleanText,
  corsHeaders,
  hasAnswer,
  json,
  normalizeAnswer,
  parseJsonBody,
  safeFilename,
  storagePathFromCv
});
