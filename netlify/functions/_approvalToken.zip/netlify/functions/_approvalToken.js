var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var approvalToken_exports = {};
__export(approvalToken_exports, {
  createApprovalToken: () => createApprovalToken,
  verifyApprovalToken: () => verifyApprovalToken
});
module.exports = __toCommonJS(approvalToken_exports);
var import_crypto = __toESM(require("crypto"));
function getSecret() {
  return process.env.DRAFT_APPROVAL_SECRET || process.env.FIREBASE_PRIVATE_KEY || process.env.FIREBASE_CLIENT_EMAIL || "";
}
function hmac(value) {
  const secret = getSecret();
  if (!secret) return "";
  return import_crypto.default.createHmac("sha256", secret.replace(/\\n/g, "\n")).update(value).digest("hex");
}
function createApprovalToken(id) {
  return hmac(`approve-draft:${id}`);
}
function verifyApprovalToken(id, token) {
  const expected = createApprovalToken(id);
  if (!expected || !token) return false;
  const expectedBuffer = Buffer.from(expected, "hex");
  const tokenBuffer = Buffer.from(String(token), "hex");
  if (expectedBuffer.length !== tokenBuffer.length) return false;
  return import_crypto.default.timingSafeEqual(expectedBuffer, tokenBuffer);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createApprovalToken,
  verifyApprovalToken
});
