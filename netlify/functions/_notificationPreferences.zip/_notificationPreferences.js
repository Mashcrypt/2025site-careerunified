var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/_notificationPreferences.ts
var notificationPreferences_exports = {};
__export(notificationPreferences_exports, {
  userAllowsNotification: () => userAllowsNotification
});
module.exports = __toCommonJS(notificationPreferences_exports);
function selectedValues(value) {
  return Array.isArray(value) ? value.filter((item) => typeof item === "string") : [];
}
async function userAllowsNotification({
  admin,
  userId,
  channel,
  opportunityType = "",
  industry = "",
  updateType = "",
  allowWhenMissing = false
}) {
  const uid = String(userId || "").trim();
  if (!uid) return { allowed: false, reason: "missing-preferences" };
  const userSnap = await admin.firestore().doc(`users/${uid}`).get();
  const userData = userSnap.exists ? userSnap.data() || {} : {};
  const preferences = userData.notificationPreferences;
  const hasPreferences = preferences && typeof preferences === "object" && !Array.isArray(preferences);
  if (!hasPreferences) {
    return {
      allowed: allowWhenMissing,
      reason: allowWhenMissing ? "allowed" : "missing-preferences"
    };
  }
  if (preferences.enabled !== true) {
    return { allowed: false, reason: "alerts-disabled" };
  }
  if (!selectedValues(preferences.channels).includes(channel)) {
    return { allowed: false, reason: "channel-disabled" };
  }
  if (updateType && !selectedValues(preferences.updates).includes(updateType)) {
    return { allowed: false, reason: "type-disabled" };
  }
  if (opportunityType && !selectedValues(preferences.opportunityTypes).includes(opportunityType)) {
    return { allowed: false, reason: "type-disabled" };
  }
  const industries = selectedValues(preferences.industries);
  if (industry && industries.length && !industries.includes(industry) && !industries.includes("General / Any Industry")) {
    return { allowed: false, reason: "type-disabled" };
  }
  return { allowed: true, reason: "allowed" };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  userAllowsNotification
});
