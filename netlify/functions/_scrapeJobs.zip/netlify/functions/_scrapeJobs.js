var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var scrapeJobs_exports = {};
__export(scrapeJobs_exports, {
  fetchLatestBursariesFromSite: () => fetchLatestBursariesFromSite,
  fetchLatestJobsFromSite: () => fetchLatestJobsFromSite
});
module.exports = __toCommonJS(scrapeJobs_exports);
function toText(value) {
  if (value == null) return "";
  if (typeof value === "string") return value;
  if (typeof value === "number" || typeof value === "boolean") return String(value);
  if (Array.isArray(value)) {
    return value.map(toText).filter(Boolean).join(" ");
  }
  if (typeof value === "object") {
    if (typeof value.current === "string") return value.current;
    if (typeof value.title === "string") return value.title;
    if (typeof value.name === "string") return value.name;
    if (typeof value.value === "string") return value.value;
    if (typeof value.text === "string") return value.text;
    if (Array.isArray(value.children)) {
      return value.children.map(toText).filter(Boolean).join(" ");
    }
  }
  return "";
}
function clean(value = "") {
  return toText(value).replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim();
}
async function querySanity({ type, limit, basePath }) {
  const projectId = process.env.VITE_SANITY_PROJECT_ID || "qjg5raj1";
  const dataset = process.env.VITE_SANITY_DATASET || "production";
  const query = `*[_type == "${type}"] | order(_createdAt desc)[0...${limit}]{
    title,
    company,
    location,
    salary,
    closingDate,
    "slug": slug.current
  }`;
  const url = `https://${projectId}.api.sanity.io/v2023-10-01/data/query/${dataset}?query=${encodeURIComponent(query)}`;
  const resp = await fetch(url, {
    headers: { Accept: "application/json" }
  });
  if (!resp.ok) {
    const err = await resp.text();
    throw new Error(`Sanity fetch failed for ${type}: ${resp.status} ${err}`);
  }
  const data = await resp.json();
  const items = Array.isArray(data?.result) ? data.result : [];
  return items.filter((item) => item?.slug).map((item) => ({
    title: clean(item.title) || "Untitled",
    company: clean(item.company) || "Not specified",
    location: clean(item.location) || "Not specified",
    salary: clean(item.salary) || "Not specified",
    closingDate: clean(item.closingDate) || "Not specified",
    url: `https://careerunified.com/${basePath}/${clean(item.slug)}`
  }));
}
async function fetchLatestJobsFromSite(limit = 3) {
  return querySanity({
    type: "job",
    limit,
    basePath: "jobs"
  });
}
async function fetchLatestBursariesFromSite(limit = 3) {
  return querySanity({
    type: "bursary",
    limit,
    basePath: "bursary"
  });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  fetchLatestBursariesFromSite,
  fetchLatestJobsFromSite
});
