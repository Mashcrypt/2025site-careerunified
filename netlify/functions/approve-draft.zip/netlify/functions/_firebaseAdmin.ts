var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var firebaseAdmin_exports = {};
__export(firebaseAdmin_exports, {
  getAdmin: () => getAdmin,
  getDb: () => getDb
});
module.exports = __toCommonJS(firebaseAdmin_exports);
var import_app = require("firebase-admin/app");
var import_auth = require("firebase-admin/auth");
var import_firestore = require("firebase-admin/firestore");
var import_storage = require("firebase-admin/storage");
function ensureApp() {
  if (!(0, import_app.getApps)().length) {
    if (!process.env.FIREBASE_PROJECT_ID || !process.env.FIREBASE_CLIENT_EMAIL || !process.env.FIREBASE_PRIVATE_KEY) {
      throw new Error(
        "Missing Firebase Admin credentials. Set FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, and FIREBASE_PRIVATE_KEY."
      );
    }
    (0, import_app.initializeApp)({
      credential: (0, import_app.cert)({
        projectId: process.env.FIREBASE_PROJECT_ID,
        clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
        privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, "\n")
      })
    });
  }
}
const firestore = Object.assign(() => {
  ensureApp();
  return (0, import_firestore.getFirestore)();
}, { FieldValue: import_firestore.FieldValue, Timestamp: import_firestore.Timestamp });
const adminCompat = {
  auth() {
    ensureApp();
    return (0, import_auth.getAuth)();
  },
  firestore,
  storage() {
    ensureApp();
    return (0, import_storage.getStorage)();
  }
};
function getAdmin() {
  ensureApp();
  return adminCompat;
}
function getDb() {
  return getAdmin().firestore();
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  getAdmin,
  getDb
});
