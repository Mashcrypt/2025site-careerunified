var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var rateLimit_exports = {};
__export(rateLimit_exports, {
  checkRateLimit: () => checkRateLimit,
  clientIpFromHeaders: () => clientIpFromHeaders
});
module.exports = __toCommonJS(rateLimit_exports);
var import_crypto = __toESM(require("crypto"));
var import_net = __toESM(require("net"));
function hash(value) {
  return import_crypto.default.createHash("sha256").update(value).digest("hex");
}
async function checkRateLimit({
  admin,
  action,
  identifier,
  limit,
  windowSeconds
}) {
  const nowMs = Date.now();
  const windowMs = windowSeconds * 1e3;
  const bucket = Math.floor(nowMs / windowMs);
  const windowEndMs = (bucket + 1) * windowMs;
  const id = hash(`${action}:${identifier}:${bucket}`);
  const identifierHash = hash(identifier);
  const ref = admin.firestore().collection("rateLimits").doc(id);
  let result = {
    allowed: true,
    remaining: Math.max(0, limit - 1),
    retryAfterSeconds: 0
  };
  await admin.firestore().runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    const currentCount = Number(snap.data()?.count || 0);
    if (currentCount >= limit) {
      result = {
        allowed: false,
        remaining: 0,
        retryAfterSeconds: Math.max(1, Math.ceil((windowEndMs - nowMs) / 1e3))
      };
      return;
    }
    const nextCount = currentCount + 1;
    tx.set(
      ref,
      {
        action,
        identifierHash,
        bucket,
        count: nextCount,
        limit,
        windowSeconds,
        windowEndsAt: admin.firestore.Timestamp.fromMillis(windowEndMs),
        createdAt: snap.exists ? snap.data()?.createdAt || admin.firestore.FieldValue.serverTimestamp() : admin.firestore.FieldValue.serverTimestamp(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp()
      },
      { merge: true }
    );
    result = {
      allowed: true,
      remaining: Math.max(0, limit - nextCount),
      retryAfterSeconds: 0
    };
  });
  return result;
}
function clientIpFromHeaders(headers) {
  const netlifyIp = headers["x-nf-client-connection-ip"] || headers["X-Nf-Client-Connection-Ip"];
  const forwarded = headers["x-forwarded-for"] || headers["X-Forwarded-For"];
  const clientIp = headers["client-ip"] || headers["Client-Ip"];
  const candidates = [netlifyIp, forwarded?.split(",")[0], clientIp];
  for (const candidate of candidates) {
    const value = String(candidate || "").trim().replace(/^\[|\]$/g, "");
    if (import_net.default.isIP(value)) return value;
  }
  return "unknown";
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  checkRateLimit,
  clientIpFromHeaders
});
