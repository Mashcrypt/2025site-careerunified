var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var approve_draft_exports = {};
__export(approve_draft_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(approve_draft_exports);
var import_firebaseAdmin = require("./_firebaseAdmin");
var import_approvalToken = require("./_approvalToken");
var import_rateLimit = require("./_rateLimit");
const COLLECTION = "post_drafts";
function escapeHtml(s = "") {
  return s.replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[c]);
}
async function handler(event) {
  try {
    const id = event.queryStringParameters?.id;
    const token = event.queryStringParameters?.token;
    if (!id) {
      return { statusCode: 400, body: "Missing id" };
    }
    if (!token || !(0, import_approvalToken.verifyApprovalToken)(id, token)) {
      return { statusCode: 403, body: "Invalid or expired approval link" };
    }
    const admin = (0, import_firebaseAdmin.getAdmin)();
    const db = admin.firestore();
    const rateLimit = await (0, import_rateLimit.checkRateLimit)({
      admin,
      action: "draft-approval",
      identifier: `ip:${(0, import_rateLimit.clientIpFromHeaders)(event.headers)}`,
      limit: 20,
      windowSeconds: 60 * 60
    });
    if (!rateLimit.allowed) {
      return {
        statusCode: 429,
        headers: { "Retry-After": String(rateLimit.retryAfterSeconds) },
        body: "Too many approval attempts. Please try again later."
      };
    }
    const ref = db.collection(COLLECTION).doc(id);
    const snap = await ref.get();
    if (!snap.exists) {
      return { statusCode: 404, body: "Draft not found" };
    }
    const data = snap.data() || {};
    if (data.status === "PENDING") {
      await ref.update({
        status: "APPROVED",
        approvedAt: /* @__PURE__ */ new Date()
      });
    }
    const postText = data.postText || "";
    const safeText = escapeHtml(postText);
    const html = `<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Approve Draft</title>
  <style>
    body { font-family: system-ui, Arial, sans-serif; padding: 16px; max-width: 760px; margin: 0 auto; }
    pre { white-space: pre-wrap; background: #f6f7f9; padding: 14px; border-radius: 12px; line-height: 1.6; }
    button { padding: 10px 14px; border-radius: 10px; border: 0; cursor: pointer; font-size: 16px; }
  </style>
</head>
<body>
  <h2>Approved \u2705</h2>
  <p>Copy and paste this into your WhatsApp Channel:</p>
  <button id="copyBtn">Copy</button>
  <pre id="txt">${safeText}</pre>
  <script>
    const text = ${JSON.stringify(postText)};
    document.getElementById("copyBtn").addEventListener("click", async () => {
      await navigator.clipboard.writeText(text);
      alert("Copied!");
    });
  </script>
</body>
</html>`;
    return {
      statusCode: 200,
      headers: { "Content-Type": "text/html" },
      body: html
    };
  } catch (e) {
    return {
      statusCode: 500,
      body: `Error: ${e?.message || String(e)}`
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
