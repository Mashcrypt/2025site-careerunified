var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/sitemap.ts
var sitemap_exports = {};
__export(sitemap_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(sitemap_exports);
var SITE_URL = "https://careerunified.com";
var PROJECT_ID = process.env.VITE_SANITY_PROJECT_ID || "qjg5raj1";
var DATASET = process.env.VITE_SANITY_DATASET || "production";
var API_VERSION = "2023-10-01";
var STATIC_LASTMOD = "2026-07-09";
function slugify(value) {
  return String(value || "").toLowerCase().trim().replace(/&/g, "and").replace(/[-_]+/g, " ").replace(/\bapply\s+now\b/g, "").replace(/\bclosing\s+soon\b/g, "").replace(/\bor\s+apply\b/g, "").replace(/\bapply\b$/g, "").replace(/\bor\b/g, "").replace(/speciliast/g, "specialist").replace(/machanical/g, "mechanical").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}
var today = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
function escapeXml(value) {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function dateOnly(value) {
  if (!value) return today();
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return String(value).slice(0, 10);
  return parsed.toISOString().slice(0, 10);
}
function sanityUrl(query) {
  return `https://${PROJECT_ID}.api.sanity.io/v${API_VERSION}/data/query/${DATASET}?query=${encodeURIComponent(query)}`;
}
function staticEntries() {
  return [
    { loc: `${SITE_URL}/`, lastmod: "2026-08-08", changefreq: "weekly", priority: "1.0" },
    { loc: `${SITE_URL}/jobs`, lastmod: STATIC_LASTMOD, changefreq: "daily", priority: "0.9" },
    { loc: `${SITE_URL}/bursaries`, lastmod: STATIC_LASTMOD, changefreq: "daily", priority: "0.9" },
    { loc: `${SITE_URL}/varsity`, lastmod: STATIC_LASTMOD, changefreq: "weekly", priority: "0.85" },
    { loc: `${SITE_URL}/cv-tips`, lastmod: STATIC_LASTMOD, changefreq: "weekly", priority: "0.85" },
    { loc: `${SITE_URL}/cv-generator/`, lastmod: STATIC_LASTMOD, changefreq: "monthly", priority: "0.8" },
    { loc: `${SITE_URL}/z83-filler`, lastmod: STATIC_LASTMOD, changefreq: "monthly", priority: "0.8" },
    { loc: `${SITE_URL}/guides/how-to-complete-z83-form`, lastmod: "2026-07-18", changefreq: "monthly", priority: "0.85" },
    { loc: `${SITE_URL}/for-recruiters`, lastmod: "2026-08-08", changefreq: "monthly", priority: "0.75" },
    { loc: `${SITE_URL}/api/`, lastmod: "2026-08-18", changefreq: "monthly", priority: "0.7" },
    { loc: `${SITE_URL}/blog`, lastmod: "2026-08-10", changefreq: "weekly", priority: "0.75" },
    { loc: `${SITE_URL}/guides`, lastmod: "2026-08-10", changefreq: "monthly", priority: "0.8" },
    { loc: `${SITE_URL}/webinars`, lastmod: "2026-08-10", changefreq: "monthly", priority: "0.55" },
    { loc: `${SITE_URL}/case-studies`, lastmod: "2026-08-10", changefreq: "monthly", priority: "0.65" },
    { loc: `${SITE_URL}/about-us`, lastmod: STATIC_LASTMOD, changefreq: "monthly", priority: "0.6" },
    { loc: `${SITE_URL}/contact-us`, lastmod: STATIC_LASTMOD, changefreq: "monthly", priority: "0.5" },
    { loc: `${SITE_URL}/privacy`, lastmod: STATIC_LASTMOD, changefreq: "yearly", priority: "0.3" },
    { loc: `${SITE_URL}/terms`, lastmod: STATIC_LASTMOD, changefreq: "yearly", priority: "0.3" },
    { loc: `${SITE_URL}/paia-manual`, lastmod: "2026-08-21", changefreq: "yearly", priority: "0.3" }
  ];
}
async function fetchSanityItems(type, limit = 2e3) {
  const slugPath = type === "university" ? `"slug": slug.current` : `"slug": coalesce(slug.current, _id)`;
  const deadlineFilter = type === "university" ? "" : ` && (!defined(deadline) || deadline >= "${today()}")`;
  const query = `*[_type == "${type}"${deadlineFilter}] | order(coalesce(_updatedAt, _createdAt) desc)[0...${limit}]{
    ${slugPath},
    title,
    name,
    _updatedAt,
    _createdAt,
    posted,
    deadline
  }`;
  const response = await fetch(sanityUrl(query), {
    headers: { Accept: "application/json" }
  });
  if (!response.ok) {
    throw new Error(`Sanity sitemap fetch failed for ${type}: ${response.status}`);
  }
  const data = await response.json();
  const items = Array.isArray(data?.result) ? data.result : [];
  return type === "university" ? items.map((item) => ({ ...item, slug: item.slug || slugify(item.name) })) : items;
}
function opportunityEntries(items, basePath, priority) {
  return items.map((item) => ({
    ...item,
    slug: slugify(item.slug || item.title || item.name)
  })).filter((item) => item.slug).map((item) => ({
    loc: `${SITE_URL}/${basePath}/${encodeURIComponent(String(item.slug))}`,
    lastmod: dateOnly(item._updatedAt || item.posted || item._createdAt || item.deadline),
    changefreq: "daily",
    priority
  }));
}
function uniqueEntries(entries) {
  const seen = /* @__PURE__ */ new Set();
  return entries.filter((entry) => {
    if (seen.has(entry.loc)) return false;
    seen.add(entry.loc);
    return true;
  });
}
function renderXml(entries) {
  const urls = entries.map(
    (entry) => `  <url>
    <loc>${escapeXml(entry.loc)}</loc>
    <lastmod>${escapeXml(entry.lastmod)}</lastmod>
    <changefreq>${entry.changefreq}</changefreq>
    <priority>${entry.priority}</priority>
  </url>`
  ).join("\n\n");
  return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls}
</urlset>
`;
}
var handler = async () => {
  const entries = staticEntries();
  try {
    const [jobs, bursaries, universities] = await Promise.all([
      fetchSanityItems("job"),
      fetchSanityItems("bursary"),
      fetchSanityItems("university")
    ]);
    entries.push(...opportunityEntries(jobs, "jobs", "0.85"));
    entries.push(...opportunityEntries(bursaries, "bursary", "0.85"));
    entries.push(...opportunityEntries(universities, "varsity", "0.8"));
  } catch (error) {
    console.error("Dynamic sitemap Sanity fetch failed:", error);
  }
  return {
    statusCode: 200,
    headers: {
      "Content-Type": "application/xml; charset=utf-8",
      "Cache-Control": "public, max-age=900, stale-while-revalidate=3600"
    },
    body: renderXml(uniqueEntries(entries))
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
