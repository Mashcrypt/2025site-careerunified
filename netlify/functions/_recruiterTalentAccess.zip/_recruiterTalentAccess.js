var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/_recruiterTalentAccess.ts
var recruiterTalentAccess_exports = {};
__export(recruiterTalentAccess_exports, {
  recruiterTalentAccess: () => recruiterTalentAccess
});
module.exports = __toCommonJS(recruiterTalentAccess_exports);
var PAID_PLANS = /* @__PURE__ */ new Set(["starter", "pro", "enterprise"]);
function timestampMillis(value) {
  if (!value) return 0;
  if (typeof value.toMillis === "function") return value.toMillis();
  if (typeof value.toDate === "function") return value.toDate().getTime();
  if (typeof value.seconds === "number") return value.seconds * 1e3;
  const parsed = value instanceof Date ? value : new Date(value);
  const millis = parsed.getTime();
  return Number.isFinite(millis) ? millis : 0;
}
function recruiterTalentAccess(data, now = Date.now()) {
  const storedPlan = String(data.plan || "free").toLowerCase();
  const subscriptionActive = data.subscriptionStatus === "active" && PAID_PLANS.has(storedPlan) && timestampMillis(data.subscriptionCurrentPeriodEnd) > now;
  const trialActive = data.subscriptionStatus === "trialing" && timestampMillis(data.trialEndsAt) > now;
  const plan = subscriptionActive ? storedPlan : trialActive ? "pro" : "free";
  const unlockedCVs = Array.isArray(data.unlockedCVs) ? data.unlockedCVs.filter((value) => typeof value === "string").slice(0, 1e3) : [];
  return {
    active: subscriptionActive || trialActive,
    plan,
    unlimited: plan === "enterprise",
    unlockedCVs,
    unlocksRemaining: Number.isFinite(Number(data.unlocksRemaining)) ? Number(data.unlocksRemaining) : 0
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  recruiterTalentAccess
});
